CREATE FUNCTION nextVal(seq_name VARCHAR(50))
  RETURNS INT
  BEGIN
    UPDATE sequence
    SET currentValue = currentValue + increment
    WHERE seqname = seq_name;
    RETURN currentVal(seq_name);
  END;
