CREATE FUNCTION currentVal(seq_name VARCHAR(50))
  RETURNS INT
  BEGIN
    DECLARE current INTEGER;
    SET current = 0;
    SELECT currentValue INTO current
    FROM sequence
    WHERE seqname = seq_name;
    RETURN current;
  END;
